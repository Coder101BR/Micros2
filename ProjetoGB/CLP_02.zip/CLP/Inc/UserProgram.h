/*
 * UserProgram.h
 *
 *  Created on: 11 de jun de 2018
 *      Author: Gabriel
 */

#ifndef USERPROGRAM_H_
#define USERPROGRAM_H_



#endif /* USERPROGRAM_H_ */


/* Includes ------------------------------------------------------------------*/
#include "stm32f3xx_hal.h"
#include "main.h"

void CallUserProgram(int Digital_Analog, int Digital_Input, int *Output);
int ScanTimeLimit();
