/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "main.h"
#include "stm32f3xx_hal.h"
#include "adc.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
/* USER CODE BEGIN Includes */     
#include "user_5110.h"
/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/
osThreadId Task_0Handle;
osThreadId Task_1Handle;
osThreadId myTask03Handle;
osThreadId myTask04Handle;
osThreadId myTask05Handle;
osThreadId myTask06Handle;
osThreadId myTask07Handle;
osThreadId myTask08Handle;
osThreadId myTask09Handle;
osThreadId Task_2Handle;
osMutexId myMutex01Handle;
osMutexId PrintMutexHandle;

/* USER CODE BEGIN Variables */

int media_01[10] = {0,0,0,0,0,
					0,0,0,0,0};
int media_02[10] = {0,0,0,0,0,
					0,0,0,0,0};

/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartTask_0(void const * argument);
void StartTask_1(void const * argument);
void StartTask03(void const * argument);
void StartTask04(void const * argument);
void StartTask05(void const * argument);
void StartTask06(void const * argument);
void StartTask07(void const * argument);
void StartTask08(void const * argument);
void StartTask09(void const * argument);
void StartTask_2(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
// func



/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */



  /* USER CODE END Init */

  /* Create the mutex(es) */
  /* definition and creation of myMutex01 */
  osMutexDef(myMutex01);
  myMutex01Handle = osMutexCreate(osMutex(myMutex01));

  /* definition and creation of PrintMutex */
  osMutexDef(PrintMutex);
  PrintMutexHandle = osMutexCreate(osMutex(PrintMutex));

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of Task_0 */
  osThreadDef(Task_0, StartTask_0, osPriorityNormal, 0, 128);
  Task_0Handle = osThreadCreate(osThread(Task_0), NULL);

  /* definition and creation of Task_1 */
  osThreadDef(Task_1, StartTask_1, osPriorityNormal, 0, 128);
  Task_1Handle = osThreadCreate(osThread(Task_1), NULL);

  /* definition and creation of myTask03 */
  osThreadDef(myTask03, StartTask03, osPriorityNormal, 0, 128);
  myTask03Handle = osThreadCreate(osThread(myTask03), NULL);

  /* definition and creation of myTask04 */
  osThreadDef(myTask04, StartTask04, osPriorityNormal, 0, 128);
  myTask04Handle = osThreadCreate(osThread(myTask04), NULL);

  /* definition and creation of myTask05 */
  osThreadDef(myTask05, StartTask05, osPriorityNormal, 0, 128);
  myTask05Handle = osThreadCreate(osThread(myTask05), NULL);

  /* definition and creation of myTask06 */
  osThreadDef(myTask06, StartTask06, osPriorityNormal, 0, 128);
  myTask06Handle = osThreadCreate(osThread(myTask06), NULL);

  /* definition and creation of myTask07 */
  osThreadDef(myTask07, StartTask07, osPriorityNormal, 0, 128);
  myTask07Handle = osThreadCreate(osThread(myTask07), NULL);

  /* definition and creation of myTask08 */
  osThreadDef(myTask08, StartTask08, osPriorityNormal, 0, 128);
  myTask08Handle = osThreadCreate(osThread(myTask08), NULL);

  /* definition and creation of myTask09 */
  osThreadDef(myTask09, StartTask09, osPriorityNormal, 0, 128);
  myTask09Handle = osThreadCreate(osThread(myTask09), NULL);

  /* definition and creation of Task_2 */
  osThreadDef(Task_2, StartTask_2, osPriorityNormal, 0, 128);
  Task_2Handle = osThreadCreate(osThread(Task_2), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */


  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* StartTask_0 function */
void StartTask_0(void const * argument)
{

  /* USER CODE BEGIN StartTask_0 */
	char buffer[20];
	int i = 0;
	uint32_t g_ADCValue = 0;
  /* Infinite loop */
  for(;;)
  {
	  osMutexWait(PrintMutexHandle, 5000);
	    HAL_ADC_Start(&hadc1); // Inicia a amostragem do primeiro canal


		 if (HAL_ADC_PollForConversion(&hadc1, 1000000) == HAL_OK)
		 {
			 // Le o valor do primeiro canal
			g_ADCValue = HAL_ADC_GetValue(&hadc1);
			media_01[i] = g_ADCValue;
		 }

		//sprintf(buffer, "%d", g_ADCValue);
		//printf("A0: %s\r\n", buffer);
		//LCD_Write_String(0,0,buffer);
		osMutexRelease(PrintMutexHandle);

		// reset i index
		if(i >= 9)
		{
			i = 0;
		}

    osDelay(10);
  }
  /* USER CODE END StartTask_0 */
}

/* StartTask_1 function */
void StartTask_1(void const * argument)
{
  /* USER CODE BEGIN StartTask_1 */
	char buffer[20];
	uint32_t g_ADCValue = 0;
	int i = 0;
  /* Infinite loop */
  for(;;)
  {
	  osMutexWait(PrintMutexHandle, 5000);
		HAL_ADC_Start(&hadc1); // Inicia a amostragem do primeiro canal
		 if (HAL_ADC_PollForConversion(&hadc1, 1000000) == HAL_OK)
		 {
		     // Le o valor do segundo canal
		     g_ADCValue = HAL_ADC_GetValue(&hadc1);
		     media_02[i] = g_ADCValue;
		 }

		//sprintf(buffer, "%d", g_ADCValue);
		//printf("A1: %s\r\n", buffer);
		//LCD_Write_String(0,0,buffer);
		osMutexRelease(PrintMutexHandle);

		// reset i index
		if(i >= 9)
		{
			i = 0;
		}

		osDelay(10);
  }
  /* USER CODE END StartTask_1 */
}

/* StartTask03 function */
void StartTask03(void const * argument)
{
  /* USER CODE BEGIN StartTask03 */
 int soma_1 = 0;
 int soma_2 = 0;
 int i = 0;
 char buffer[20];
  /* Infinite loop */
  for(;;)
  {

	  for(int i = 0; i < 10; i++)
	  {
		  soma_1 = media_01[i];
		  soma_2 = media_02[i];
	  }

	sprintf(buffer, "%d", soma_1);
	printf("A0: %s\r\n", buffer);
	LCD_Write_String(0,0,buffer);

	sprintf(buffer, "%d", soma_2);
	printf("A1: %s\r\n", buffer);
	LCD_Write_String(0,1,buffer);

    osDelay(1000);
  }
  /* USER CODE END StartTask03 */
}

/* StartTask04 function */
void StartTask04(void const * argument)
{
  /* USER CODE BEGIN StartTask04 */

  /* Infinite loop */
  for(;;)
  {


    osDelay(1);
  }
  /* USER CODE END StartTask04 */
}

/* StartTask05 function */
void StartTask05(void const * argument)
{
  /* USER CODE BEGIN StartTask05 */
	char buffer[20];
  /* Infinite loop */
  for(;;)
  {


    osDelay(1);
  }
  /* USER CODE END StartTask05 */
}

/* StartTask06 function */
void StartTask06(void const * argument)
{
  /* USER CODE BEGIN StartTask06 */

  /* Infinite loop */
  for(;;)
  {


    osDelay(1);
  }
  /* USER CODE END StartTask06 */
}

/* StartTask07 function */
void StartTask07(void const * argument)
{
  /* USER CODE BEGIN StartTask07 */

  /* Infinite loop */
  for(;;)
  {

    osDelay(1);
  }
  /* USER CODE END StartTask07 */
}

/* StartTask08 function */
void StartTask08(void const * argument)
{
  /* USER CODE BEGIN StartTask08 */

  /* Infinite loop */
  for(;;)
  {

    osDelay(1);
  }
  /* USER CODE END StartTask08 */
}

/* StartTask09 function */
void StartTask09(void const * argument)
{
  /* USER CODE BEGIN StartTask09 */

  /* Infinite loop */
  for(;;)
  {

    osDelay(1);
  }
  /* USER CODE END StartTask09 */
}

/* StartTask_2 function */
void StartTask_2(void const * argument)
{
  /* USER CODE BEGIN StartTask_2 */
	char buffer[20];
  /* Infinite loop */
  for(;;)
  {


    osDelay(1);
  }
  /* USER CODE END StartTask_2 */
}

/* USER CODE BEGIN Application */
     
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
